--Consultas SQL

USE Staging_jardineria;

--Origen_Cliente
SELECT ID_cliente, nombre_cliente, nombre_contacto, apellido_contacto, telefono, region, pais, codigo_postal
FROM cliente
ORDER BY ID_cliente;

--Destino_Cliente
CREATE TABLE "cliente" (
    "ID_cliente" int identity (1,1),
    "ID_cliente_o" int,
    "nombre_cliente" nvarchar(50),
    "nombre_contacto" nvarchar(30),
    "apellido_contacto" nvarchar(30),
    "telefono" nvarchar(15),
    "region" nvarchar(50),
    "pais" nvarchar(50),
    "codigo_postal" nvarchar(10),
primary key("ID_cliente")
)

--Origen_Pago
SELECT ID_pago, ID_cliente, forma_pago, total
FROM pago
ORDER BY ID_pago;

--Destino_Pago
CREATE TABLE "pago" (
    "ID_pago" int identity (1,1),
    "ID_pago_o" int,
    "ID_cliente" int,
    "forma_pago" nvarchar(40),
    "total" numeric(15,2),
     primary key("ID_pago")
)

--Origen_Producto
SELECT ID_producto, CodigoProducto, nombre, Categoria, proveedor, descripcion, precio_proveedor
FROM producto
ORDER BY ID_producto;

--Destino_Producto
CREATE TABLE "producto" (
    "ID_producto" int identity (1,1),    
"ID_producto_o" int,
    "CodigoProducto" nvarchar(15),
    "nombre" nvarchar(70),
    "Categoria" int,
primary key ("ID_producto")
)

--Origen_Categoria
SELECT Id_Categoria, Desc_Categoria, descripcion_texto
FROM Categoria_producto
ORDER BY Id_Categoria;

--Destino_Categoria
CREATE TABLE "Categoria" (
"ID_Categoria" int identity (1,1),    
    "Id_Categoria_o" int,
    "Desc_Categoria" nvarchar(50),
    "descripcion_texto" nvarchar(max),
primary key ("ID_Categoria")
)

--Origen_Empleado
SELECT ID_empleado, nombre, apellido1, apellido2, extension, email, ID_oficina, puesto
FROM empleado
ORDER BY ID_empleado;

--Destino_Empleado
CREATE TABLE "Empleado" (
    "ID_empleado" int identity (1,1),    
    "ID_empleado_o" int,
    "nombre" nvarchar(50),
    "apellido1" nvarchar(50),
    "apellido2" nvarchar(50),
    "extension" nvarchar(10),
    "email" nvarchar(100),
    "ID_oficina" int,
    "puesto" nvarchar(50),
primary key ("ID_empleado")
)

--Origen_Oficina
SELECT *
FROM oficina
ORDER BY ID_oficina;


--Destino_Oficina
CREATE TABLE "Oficina" (
    "ID_oficina" int identity (1,1),    
    "ID_oficina_o" int,
    "Descripcion" nvarchar(10),
    "ciudad" nvarchar(30),
    "pais" nvarchar(50),
    "region" nvarchar(50),
    "codigo_postal" nvarchar(10),
    "telefono" nvarchar(20),
    "linea_direccion1" nvarchar(50),
    "linea_direccion2" nvarchar(50),
primary key ("ID_oficina")
)

--Origen_Tiempo
SELECT fecha_pago
FROM pago;

--Destino_Tiempo
CREATE TABLE "Tiempo" (
    "ID_fecha" int identity (1,1),    
	"fecha_pago" date,
primary key ("ID_fecha")
)


--Origen_Pedido
SELECT ID_pedido, fecha_pedido, ID_cliente
FROM pedido
ORDER BY ID_pedido;

--Destino_Pedido
CREATE TABLE "Pedidos" (
    "ID_pedido" int identity (1,1),    
    "ID_pedido_o" int,
    "fecha_pedido" date,
    "ID_cliente" int, 
primary key ("ID_pedido")
)

--Origen_Detalle_Pedido
SELECT ID_detalle_pedido, ID_pedido, ID_producto, cantidad, precio_unidad
FROM detalle_pedido
ORDER BY ID_detalle_pedido;

--Destino_Detalle_Pedido
CREATE TABLE "Detalle_Pedidos" (
    "ID_detalle_pedido" int identity (1,1),    
    "ID_detalle_pedido_o" int,
    "ID_pedido" int,
    "ID_producto" int,
    "cantidad" int,
    "precio_unidad" numeric(15,2),
primary key ("ID_detalle_pedido")
)
--Tarea Truncate SQL
truncate table cliente
truncate table pago
truncate table producto
truncate table categoria
truncate table empleado
truncate table oficina
truncate table tiempo
truncate table pedidos
truncate table Detalle_pedidos

--TRANSFORMACION

--ORIGEN DIM_CLIENTE_PAGO
SELECT COALESCE (cliente.ID_cliente, 'N/A') AS ID_cliente, COALESCE (cliente.ID_cliente_o, 'N/A') AS ID_cliente_o, COALESCE (cliente.nombre_cliente, 'N/A') AS nombre_cliente, COALESCE (cliente.nombre_contacto, 'N/A') AS nombre_contacto, 
                  COALESCE (cliente.apellido_contacto, 'N/A') AS apellido_contacto, COALESCE (cliente.telefono, 'N/A') AS telefono, COALESCE (cliente.region, 'N/A') AS region, COALESCE (cliente.pais, 'N/A') AS pais, COALESCE (cliente.codigo_postal, 
                  'N/A') AS codigo_postal, COALESCE (pago.ID_pago, 'N/A') AS ID_pago, COALESCE (pago.ID_pago_o, 'N/A') AS ID_pago_o, COALESCE (pago.ID_cliente, 'N/A') AS Expr1, COALESCE (pago.forma_pago, 'N/A') AS forma_pago, 
                  COALESCE (pago.total, 'N/A') AS total
FROM     cliente INNER JOIN
                  pago ON cliente.ID_cliente = pago.ID_cliente

--ORIGEN DIM_PRODUCTO_CATEGORIA
SELECT producto.ID_producto, producto.ID_producto_o, producto.CodigoProducto, producto.nombre, producto.Categoria, Categoria.ID_Categoria, Categoria.Id_Categoria_o, Categoria.Desc_Categoria, Categoria.descripcion_texto
FROM     producto INNER JOIN
                  Categoria ON producto.Categoria = Categoria.ID_Categoria

--ORIGEN DIM_EMPLEADO_OFICINA	
SELECT Empleado.ID_empleado, Empleado.ID_empleado_o, Empleado.nombre, Empleado.apellido1, Empleado.apellido2, Empleado.extension, Empleado.email, Empleado.ID_oficina, Empleado.puesto, Oficina.ID_oficina AS Expr1, 
                  Oficina.ID_oficina_o, Oficina.Descripcion, Oficina.ciudad, Oficina.pais, Oficina.region, Oficina.codigo_postal, Oficina.telefono, Oficina.linea_direccion1, Oficina.linea_direccion2
FROM     Empleado INNER JOIN
                  Oficina ON Empleado.ID_oficina = Oficina.ID_oficina

--ORIGEN FACT_VENTAS
SELECT Pedidos.ID_pedido, Pedidos.ID_pedido_o, Pedidos.fecha_pedido, Pedidos.ID_cliente, Detalle_Pedidos.ID_detalle_pedido, Detalle_Pedidos.ID_detalle_pedido_o, Detalle_Pedidos.ID_pedido AS Expr2, Detalle_Pedidos.ID_producto, 
                  Detalle_Pedidos.cantidad, Detalle_Pedidos.precio_unidad, DimProducto.ID_producto AS Expr3, DimProducto.ID_producto_o, DimProducto.CodigoProducto, DimProducto.nombre, DimProducto.Categoria, DimProducto.ID_Categoria, 
                  DimProducto.Id_Categoria_o, DimProducto.Desc_Categoria, DimProducto.descripcion_texto, DimCliente.ID_cliente AS Expr4, DimCliente.nombre_cliente, DimCliente.nombre_contacto, DimCliente.apellido_contacto, DimCliente.telefono, 
                  DimCliente.region, DimCliente.pais, DimCliente.codigo_postal, DimCliente.ID_empleado_rep_ventas, DimCliente.ID_pago, DimCliente.ID_pago_o, DimCliente.forma_pago, DimCliente.total, DimEmpleado.ID_empleado, 
                  DimEmpleado.ID_empleado_o, DimEmpleado.nombre AS Expr5, DimEmpleado.apellido1, DimEmpleado.apellido2, DimEmpleado.extension, DimEmpleado.email, DimEmpleado.ID_oficina, DimEmpleado.puesto, DimEmpleado.Expr1, 
                  DimEmpleado.ID_oficina_o, DimEmpleado.Descripcion, DimEmpleado.ciudad, DimEmpleado.pais AS Expr6, DimEmpleado.region AS Expr7, DimEmpleado.codigo_postal AS Expr8, DimEmpleado.telefono AS Expr9, 
                  DimEmpleado.linea_direccion1, DimEmpleado.linea_direccion2, DimTiempo.ID_fecha, DimTiempo.fecha_pedido AS Expr10, DimTiempo.Dia, DimTiempo.Mes, DimTiempo.Anio, DimTiempo.DiaSemana, DimTiempo.NumSemanaContable
FROM     Pedidos INNER JOIN
                  Detalle_Pedidos ON Pedidos.ID_pedido = Detalle_Pedidos.ID_pedido INNER JOIN
                  DimProducto ON DimProducto.ID_producto = Detalle_Pedidos.ID_producto INNER JOIN
                  DimCliente ON Pedidos.ID_cliente = DimCliente.ID_cliente INNER JOIN
                  DimEmpleado ON DimCliente.ID_empleado_rep_ventas = DimEmpleado.ID_empleado INNER JOIN
                  DimTiempo ON Pedidos.fecha_pedido = DimTiempo.fecha_pedido

--LA FACT VENTAS FUE DEPURADA EN LAS ASIGNACIONES PARA SOLAMENTE TOMAR LAS LLAVES DE LAS DEMAS DIMENSIONES Y LOS DATOS DE DETALLES CUANTITATIVOS PARA REALIZAR LOS CALCULOS. VER LA BASE DE DATOS STAGING

